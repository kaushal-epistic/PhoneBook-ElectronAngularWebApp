const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// List of columns for Contact schema
let Contact = new Schema({
  firstName: {
    type: String
  },
  lastName: {
    type: String
  },
  email: {
    type: String
  },
  phone: {
    type: Number
  }
}, {
  collection: 'contacts'
});

module.exports = mongoose.model('Contact', Contact);
