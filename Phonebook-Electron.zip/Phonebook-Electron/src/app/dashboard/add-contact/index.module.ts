import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddContactComponent } from './add-contact.component';
import { MatButtonModule, MatButton, MatFormFieldModule, MatInputModule } from '@angular/material';

const routes: Routes = [{
    path: "",
    component: AddContactComponent,
}];

@NgModule({
    imports: [
        // BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes),
        MatButtonModule, MatFormFieldModule, MatInputModule
    ],
    exports: [
        MatButtonModule, MatFormFieldModule, MatInputModule
    ],
    declarations: [
        AddContactComponent
    ]
})
export class AddContactModule { }