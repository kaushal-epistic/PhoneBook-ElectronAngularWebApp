import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule, FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MyDataServiceService } from '../../my-data-service.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {

  frmGroup: FormGroup;

  constructor(private formBuilder: FormBuilder, private service: MyDataServiceService, private router: Router) { }

  ngOnInit() {
    this.initializeForm();
  }

  // To initialize Form
  initializeForm() {
    this.frmGroup = this.formBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: [''],
      phone: ['', [Validators.required]],
    });
  }

  // Add Employee When Submit Button Is Clicked
  addEmployee() {
    if (this.frmGroup.valid) {
      let data = this.frmGroup.value;
      this.service.addEmployee(data).subscribe(() => {
        this.router.navigate(['/dashboard']);
      });
    }
  }

}
