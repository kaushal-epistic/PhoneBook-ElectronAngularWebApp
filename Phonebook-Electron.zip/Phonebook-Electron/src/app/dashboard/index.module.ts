import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard.component';
import { MatCardModule, MatToolbarModule, MatToolbar, MatButtonModule, MatButton, MatMenuModule, MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';

const routes: Routes = [{
    path: "",
    component: DashboardComponent,
    children: [
        {
            path: "",
            loadChildren: './list-contact/index.module#ListContactModule'
        },
        {
            path: "create",
            loadChildren: './add-contact/index.module#AddContactModule'
        },
        {
            path: "edit/:id",
            loadChildren: './edit-contact/index.module#EditContactModule'
        }
    ]
}];

@NgModule({
    imports: [
        // BrowserModule,
        CommonModule,
        // FormsModule,
        // ReactiveFormsModule,
        RouterModule.forChild(routes),
        MatCardModule,
        MatToolbarModule,
        MatButtonModule,
        MatMenuModule,
        MatFormFieldModule,
        MatTableModule,
        MatPaginatorModule,
        MatInputModule
    ],
    exports: [
        MatCardModule,
        MatToolbarModule,
        MatButtonModule,
        MatMenuModule,
        MatFormFieldModule,
        MatTableModule,
        MatPaginatorModule,
        MatInputModule
    ],
    declarations: [
        DashboardComponent
    ]
})
export class DashboardModule { }